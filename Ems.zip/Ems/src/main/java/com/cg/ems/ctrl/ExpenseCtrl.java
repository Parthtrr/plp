package com.cg.ems.ctrl;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.ems.dao.Repo;
import com.cg.ems.dto.Expense;

@RestController
public class ExpenseCtrl {

	@Autowired
	Repo repo;

	@PostMapping("/add/")
	public Expense add(@RequestBody Expense proj) {

		repo.save(proj);
		return proj;

	}

}
