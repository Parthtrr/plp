package com.cg.ems.dao;

import org.springframework.data.repository.CrudRepository;

import com.cg.ems.dto.Expense;

public interface Repo extends CrudRepository<Expense, String>{

}
