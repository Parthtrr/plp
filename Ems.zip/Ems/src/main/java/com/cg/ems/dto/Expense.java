package com.cg.ems.dto;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="ProjectDetails")
public class Expense {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private String expenseCode;
	private String expenseType;
	private LocalDate expenseDescription;
	public String getExpenseCode() {
		return expenseCode;
	}
	public void setExpenseCode(String expenseCode) {
		this.expenseCode = expenseCode;
	}
	public String getExpenseType() {
		return expenseType;
	}
	public void setExpenseType(String expenseType) {
		this.expenseType = expenseType;
	}
	public LocalDate getExpenseDescription() {
		return expenseDescription;
	}
	public void setExpenseDescription(LocalDate expenseDescription) {
		this.expenseDescription = expenseDescription;
	}
	@Override
	public String toString() {
		return "Project [expenseCode=" + expenseCode + ", expenseType=" + expenseType + ", expenseDescription="
				+ expenseDescription + "]";
	}
	public Expense(String expenseCode, String expenseType, LocalDate expenseDescription) {
		super();
		this.expenseCode = expenseCode;
		this.expenseType = expenseType;
		this.expenseDescription = expenseDescription;
	}
	public Expense() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
}
